
Usage:

> python 01_extract_discussions.py -l <name of tsv file containing a list of articles with id and title>

> python 02_parse_discussions.py [-d <input directory (default: "talk_pages/")>] [-o <prefix for output file names>]

