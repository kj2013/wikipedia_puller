class Error(Exception):
    pass


class MalformedWikitextError(Error):
    pass
