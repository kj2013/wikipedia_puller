from .test_section import *
from .test_indentblock import *
from .test_comment import *
from .test_talkpageparser import *
from .test_indentutils import *
from .test_mwparsermod import *
from .test_signatureutils import *
